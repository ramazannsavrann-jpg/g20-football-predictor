# G20 Football Predictor

A phone-friendly, browser-only app for managing football fixtures and running transparent Poisson Monte Carlo simulations. The prediction flow uses local fixture data, requires no account or API key, and does not need a database or server.

## Requirements

- Node.js 24 or newer
- pnpm

## Install and run locally

Extract the ZIP, open a terminal in the extracted project root, then install the workspace dependencies:

```sh
pnpm install --frozen-lockfile
```

Start the predictor on Linux or macOS:

```sh
PORT=5173 BASE_PATH=/g20-football-predictor/ pnpm --filter @workspace/g20-football-predictor run dev
```

On Windows PowerShell:

```powershell
$env:PORT = "5173"
$env:BASE_PATH = "/g20-football-predictor/"
pnpm --filter @workspace/g20-football-predictor run dev
```

Open <http://localhost:5173/g20-football-predictor/> in a browser. Keep the terminal open while using the app; press `Ctrl+C` to stop it.

## Run the calculation tests

From the project root:

```sh
pnpm --filter @workspace/g20-football-predictor run test
```

To typecheck the app:

```sh
pnpm --filter @workspace/g20-football-predictor run typecheck
```

## Android project

The Android wrapper is a Capacitor project around the existing Vite app. Its Android-specific build writes to `artifacts/g20-football-predictor/dist/android`; the existing web build and run configuration are unchanged.

From the project root, build the Android web assets and sync them into the native project:

```sh
pnpm --filter @workspace/g20-football-predictor run android:sync
```

To build an installable debug APK, use a computer with the free Android Studio and Android SDK installed:

1. Open `artifacts/g20-football-predictor/android` in Android Studio and let Gradle sync.
2. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. The debug APK is created at `artifacts/g20-football-predictor/android/app/build/outputs/apk/debug/app-debug.apk`. Android signs this debug build with a local debug key; a release-signed APK requires a private signing key kept on your own computer.
4. Copy the APK to your Android phone, open it, and approve installation for the file app if Android asks.

This Replit environment does not include Java, Gradle, or the Android SDK, so it can prepare and sync the Android project but cannot build an APK here. If you only have your phone and no computer, Chrome's **Add to Home screen** option installs the web app shortcut, but that is not an APK. No publishing, paid service, cloud build, or API key is required for these steps.

## Data and limitations

- The included fixtures and sample goal values are illustrative, not real match data or statistics.
- Imported goal rates are user-provided and are not independently verified.
- Missing rates use the stated fallback assumptions: home 1.45 and away 1.15 expected goals.
- The independent Poisson model is experimental and has not been validated for accuracy.
- Fixture edits are saved only in the current browser. There is no live football data feed.
- Importing JSON replaces the current fixture list; export a copy first if you want to keep it.

The fixture JSON format and further details are in `artifacts/g20-football-predictor/README.md`.
