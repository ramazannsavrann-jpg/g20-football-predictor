import path from 'node:path';
import { defineConfig, mergeConfig } from 'vite';
import webConfig from './vite.config';

export default mergeConfig(
  webConfig,
  defineConfig({
    base: '/',
    build: {
      outDir: path.resolve(import.meta.dirname, 'dist/android'),
      emptyOutDir: true,
    },
  }),
);
