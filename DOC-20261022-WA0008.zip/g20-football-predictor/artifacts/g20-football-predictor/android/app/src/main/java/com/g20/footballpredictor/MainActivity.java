package com.g20.footballpredictor;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
