# G20 Football Predictor

Phone-first, browser-only football fixture manager and illustrative Poisson simulator. Fixture edits persist in local browser storage; import and export use JSON files and never contact a server.

## Run the app

Use the Replit Run button to open the app preview. It runs entirely in the browser; the prediction flow does not use the workspace API server, a database, or live football data.

## Simulation tests

From this directory, run:

```sh
npm test
```

The tests use Node's built-in test runner and cover deterministic Poisson convergence, rounded outcome totals, and entered/fallback goal-rate handling.

## Fixture JSON

Import either a fixture array or an object containing a `fixtures` array. Each fixture has `competition`, `homeTeam`, and `awayTeam`; `id`, `kickoff`, `homeExpectedGoals`, and `awayExpectedGoals` are optional. Missing IDs are generated on import. Supported competitions are encoded in the app. Expected-goal inputs must be numbers from 0 through 12. Missing inputs use the explicit fallback assumptions: home 1.45, away 1.15. Importing replaces the current fixture list in this browser; export first to keep a copy.

The preloaded fixture names and example input values are illustrative only, not real fixtures, statistics, or validated predictions. Imported goal-rate values are labeled user-provided and are not independently verified.
