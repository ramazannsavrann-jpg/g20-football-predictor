import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.g20.footballpredictor',
  appName: 'G20 Football Predictor',
  webDir: 'dist/android',
};

export default config;
