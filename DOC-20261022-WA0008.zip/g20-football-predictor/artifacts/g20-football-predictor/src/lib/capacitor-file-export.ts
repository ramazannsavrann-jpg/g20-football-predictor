import { Capacitor } from '@capacitor/core';
import { Directory, Filesystem } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

export async function shareFixtureJson(json: string): Promise<boolean> {
  if (!Capacitor.isNativePlatform()) return false;

  const { uri } = await Filesystem.writeFile({
    path: 'g20-fixtures.json',
    data: json,
    directory: Directory.Cache,
  });

  await Share.share({
    title: 'G20 Football Predictor fixtures',
    text: 'Fixture data exported as JSON.',
    url: uri,
    dialogTitle: 'Export fixture data',
  });

  return true;
}
