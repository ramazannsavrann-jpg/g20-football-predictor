export const COMPETITIONS = [
  'English Premier League',
  'Spanish La Liga',
  'Italian Serie A',
  'German Bundesliga',
  'French Ligue 1',
  'UEFA Champions League',
  'UEFA Europa League',
  'UEFA Conference League',
];

export const FALLBACK_HOME_LAMBDA = 1.45;
export const FALLBACK_AWAY_LAMBDA = 1.15;

export function goalRates(fixture) {
  return {
    home: fixture.homeExpectedGoals ?? FALLBACK_HOME_LAMBDA,
    away: fixture.awayExpectedGoals ?? FALLBACK_AWAY_LAMBDA,
    homeSource: fixture.homeExpectedGoals == null ? 'fallback' : fixture.isSample ? 'sample' : 'provided',
    awaySource: fixture.awayExpectedGoals == null ? 'fallback' : fixture.isSample ? 'sample' : 'provided',
  };
}

function seededRandom(seed) {
  let state = seed >>> 0 || 1;
  return () => {
    state ^= state << 13;
    state ^= state >>> 17;
    state ^= state << 5;
    return (state >>> 0) / 4294967296;
  };
}

function poisson(lambda, random) {
  const limit = Math.exp(-lambda);
  let product = 1;
  let count = 0;
  do {
    count += 1;
    product *= random();
  } while (product > limit);
  return count - 1;
}

function stableSeed(value) {
  let hash = 2166136261;
  for (let i = 0; i < value.length; i += 1) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function percentagesToTenths(counts, total) {
  const exact = counts.map((count) => (count / total) * 1000);
  const rounded = exact.map(Math.floor);
  const remainder = 1000 - rounded.reduce((sum, value) => sum + value, 0);
  const order = exact.map((value, index) => ({ index, fraction: value - rounded[index] }))
    .sort((a, b) => b.fraction - a.fraction);
  for (let i = 0; i < remainder; i += 1) rounded[order[i].index] += 1;
  return rounded.map((value) => value / 10);
}

export function simulateFixture(fixture, simulations = 5000) {
  if (!Number.isInteger(simulations) || simulations < 1 || simulations > 100000) {
    throw new Error('Simulation count must be a whole number from 1 to 100,000.');
  }
  const { home, away } = goalRates(fixture);
  if (![home, away].every((value) => Number.isFinite(value) && value >= 0 && value <= 12)) {
    throw new Error('Expected goals must be between 0 and 12.');
  }
  const random = seededRandom(stableSeed(`${fixture.id}|${home}|${away}|${simulations}`));
  let homeWins = 0;
  let draws = 0;
  let awayWins = 0;
  let homeGoalTotal = 0;
  let awayGoalTotal = 0;
  const scores = new Map();
  for (let i = 0; i < simulations; i += 1) {
    const homeGoals = poisson(home, random);
    const awayGoals = poisson(away, random);
    homeGoalTotal += homeGoals;
    awayGoalTotal += awayGoals;
    if (homeGoals > awayGoals) homeWins += 1;
    else if (homeGoals === awayGoals) draws += 1;
    else awayWins += 1;
    const score = `${homeGoals}–${awayGoals}`;
    scores.set(score, (scores.get(score) ?? 0) + 1);
  }
  const mostLikely = [...scores.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0], undefined, { numeric: true }))[0];
  const [homePercent, drawPercent, awayPercent] = percentagesToTenths([homeWins, draws, awayWins], simulations);
  return {
    simulations,
    homeLambda: home,
    awayLambda: away,
    homeWins,
    draws,
    awayWins,
    averageHomeGoals: homeGoalTotal / simulations,
    averageAwayGoals: awayGoalTotal / simulations,
    homePercent,
    drawPercent,
    awayPercent,
    mostLikelyScore: mostLikely[0],
    scoreFrequency: mostLikely[1],
  };
}
