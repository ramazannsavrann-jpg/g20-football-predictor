export const COMPETITIONS: readonly [
  'English Premier League',
  'Spanish La Liga',
  'Italian Serie A',
  'German Bundesliga',
  'French Ligue 1',
  'UEFA Champions League',
  'UEFA Europa League',
  'UEFA Conference League',
];
export type Competition = (typeof COMPETITIONS)[number];
export type Fixture = {
  id: string;
  competition: Competition;
  homeTeam: string;
  awayTeam: string;
  kickoff?: string;
  homeExpectedGoals?: number;
  awayExpectedGoals?: number;
  isSample?: boolean;
};
export const FALLBACK_HOME_LAMBDA: number;
export const FALLBACK_AWAY_LAMBDA: number;
export function goalRates(fixture: Fixture): {
  home: number;
  away: number;
  homeSource: 'fallback' | 'provided' | 'sample';
  awaySource: 'fallback' | 'provided' | 'sample';
};
export type SimulationResult = {
  simulations: number;
  homeLambda: number;
  awayLambda: number;
  homeWins: number;
  draws: number;
  awayWins: number;
  averageHomeGoals: number;
  averageAwayGoals: number;
  homePercent: number;
  drawPercent: number;
  awayPercent: number;
  mostLikelyScore: string;
  scoreFrequency: number;
};
export function simulateFixture(fixture: Fixture, simulations?: number): SimulationResult;
