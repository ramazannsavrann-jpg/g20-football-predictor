import test from 'node:test';
import assert from 'node:assert/strict';
import { goalRates, simulateFixture } from './simulation.mjs';

const fixture = {
  id: 'test-match',
  competition: 'English Premier League',
  homeTeam: 'Northbridge FC',
  awayTeam: 'Riverside Athletic',
};

test('Poisson runs are stable and converge near the configured mean', () => {
  const result = simulateFixture({ ...fixture, homeExpectedGoals: 2, awayExpectedGoals: 1 }, 100000);
  assert.ok(Math.abs(result.averageHomeGoals - 2) < 0.025);
  assert.ok(Math.abs(result.averageAwayGoals - 1) < 0.02);
  assert.deepEqual(
    simulateFixture({ ...fixture, homeExpectedGoals: 2, awayExpectedGoals: 1 }, 100000),
    result,
  );
  assert.ok(result.homeLambda === 2 && result.awayLambda === 1);
});

test('outcome percentages sum to exactly 100.0 after rounding', () => {
  const result = simulateFixture(fixture, 5000);
  assert.equal(result.homePercent + result.drawPercent + result.awayPercent, 100);
});

test('missing goal rates use explicit fallbacks and entered rates are preserved', () => {
  assert.deepEqual(goalRates(fixture), {
    home: 1.45, away: 1.15, homeSource: 'fallback', awaySource: 'fallback',
  });
  assert.deepEqual(goalRates({ ...fixture, homeExpectedGoals: 1.9, awayExpectedGoals: 0.8 }), {
    home: 1.9, away: 0.8, homeSource: 'provided', awaySource: 'provided',
  });
});

test('preloaded sample rates are not mislabeled as user-provided statistics', () => {
  assert.deepEqual(goalRates({
    ...fixture,
    homeExpectedGoals: 1.62,
    awayExpectedGoals: 1.08,
    isSample: true,
  }), {
    home: 1.62,
    away: 1.08,
    homeSource: 'sample',
    awaySource: 'sample',
  });
});
