import { type FormEvent, useEffect, useMemo, useRef, useState } from 'react';
import { ArrowDownToLine, ArrowUpFromLine, Check, ChevronDown, Clipboard, FilePlus2, Info, Pencil, RotateCcw, Trash2, X } from 'lucide-react';
import { Capacitor } from '@capacitor/core';
import { shareFixtureJson } from '@/lib/capacitor-file-export';
import { COMPETITIONS, type Competition, type Fixture, goalRates, simulateFixture } from './simulation.mjs';

const STORAGE_KEY = 'g20-football-predictor-fixtures-v1';
const initialFixtures: Fixture[] = [
  { id: 'sample-1', competition: 'English Premier League', homeTeam: 'Northbridge FC', awayTeam: 'Riverside Athletic', homeExpectedGoals: 1.62, awayExpectedGoals: 1.08, isSample: true },
  { id: 'sample-2', competition: 'Spanish La Liga', homeTeam: 'Real Monteluz', awayTeam: 'Atlético del Puerto', isSample: true },
  { id: 'sample-3', competition: 'UEFA Champions League', homeTeam: 'FC Alderwick', awayTeam: 'Olympique Valenne', homeExpectedGoals: 1.35, isSample: true },
];

type FormValue = {
  competition: Competition;
  homeTeam: string;
  awayTeam: string;
  kickoff: string;
  homeExpectedGoals: string;
  awayExpectedGoals: string;
};

const blankForm: FormValue = {
  competition: 'English Premier League',
  homeTeam: '',
  awayTeam: '',
  kickoff: '',
  homeExpectedGoals: '',
  awayExpectedGoals: '',
};

function loadFixtures(): Fixture[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return initialFixtures;
    const parsed: unknown = JSON.parse(stored);
    return validateFixtureList(parsed);
  } catch {
    return initialFixtures;
  }
}

function validateFixtureList(input: unknown): Fixture[] {
  const rows = Array.isArray(input) ? input : typeof input === 'object' && input !== null && 'fixtures' in input ? (input as { fixtures: unknown }).fixtures : null;
  if (!Array.isArray(rows)) throw new Error('Expected a JSON array of fixtures, or an object with a "fixtures" array.');
  if (rows.length > 500) throw new Error('A maximum of 500 fixtures can be imported at once.');
  const errors: string[] = [];
  const fixtures: Fixture[] = [];
  const seenIds = new Set<string>();
  rows.forEach((row, index) => {
    const label = `Fixture ${index + 1}`;
    if (typeof row !== 'object' || row === null || Array.isArray(row)) {
      errors.push(`${label}: expected an object.`);
      return;
    }
    const item = row as Record<string, unknown>;
    if (item.id !== undefined && (typeof item.id !== 'string' || !item.id.trim())) errors.push(`${label}: id must be non-empty text when provided.`);
    const id = typeof item.id === 'string' && item.id.trim()
      ? item.id.trim()
      : `fixture-import-${Date.now()}-${index}-${Math.random().toString(36).slice(2, 8)}`;
    if (seenIds.has(id)) errors.push(`${label}: id "${id}" is duplicated.`);
    else seenIds.add(id);
    if (typeof item.competition !== 'string' || !COMPETITIONS.includes(item.competition as Competition)) errors.push(`${label}: competition must be one of the supported competitions.`);
    if (typeof item.homeTeam !== 'string' || !item.homeTeam.trim()) errors.push(`${label}: homeTeam is required.`);
    if (typeof item.awayTeam !== 'string' || !item.awayTeam.trim()) errors.push(`${label}: awayTeam is required.`);
    for (const key of ['homeExpectedGoals', 'awayExpectedGoals'] as const) {
      const value = item[key];
      if (value !== undefined && (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > 12)) {
        errors.push(`${label}: ${key} must be a number from 0 to 12.`);
      }
    }
    if (item.kickoff !== undefined && typeof item.kickoff !== 'string') errors.push(`${label}: kickoff must be text when provided.`);
    if (item.isSample !== undefined && typeof item.isSample !== 'boolean') errors.push(`${label}: isSample must be true or false when provided.`);
    if (typeof item.competition === 'string' && COMPETITIONS.includes(item.competition as Competition)
      && typeof item.homeTeam === 'string' && item.homeTeam.trim()
      && typeof item.awayTeam === 'string' && item.awayTeam.trim()
      && (item.homeExpectedGoals === undefined || (typeof item.homeExpectedGoals === 'number' && Number.isFinite(item.homeExpectedGoals) && item.homeExpectedGoals >= 0 && item.homeExpectedGoals <= 12))
      && (item.awayExpectedGoals === undefined || (typeof item.awayExpectedGoals === 'number' && Number.isFinite(item.awayExpectedGoals) && item.awayExpectedGoals >= 0 && item.awayExpectedGoals <= 12))
      && (item.kickoff === undefined || typeof item.kickoff === 'string')
      && (item.isSample === undefined || typeof item.isSample === 'boolean')
      && !errors.some((error) => error.startsWith(`${label}:`))) {
      fixtures.push({
        id,
        competition: item.competition as Competition,
        homeTeam: item.homeTeam.trim(),
        awayTeam: item.awayTeam.trim(),
        ...(typeof item.kickoff === 'string' && item.kickoff ? { kickoff: item.kickoff } : {}),
        ...(typeof item.homeExpectedGoals === 'number' ? { homeExpectedGoals: item.homeExpectedGoals } : {}),
        ...(typeof item.awayExpectedGoals === 'number' ? { awayExpectedGoals: item.awayExpectedGoals } : {}),
        ...(item.isSample === true ? { isSample: true } : {}),
      });
    }
  });
  if (errors.length) throw new Error(errors.slice(0, 8).join('\n') + (errors.length > 8 ? `\nAnd ${errors.length - 8} more issue(s).` : ''));
  return fixtures;
}

function formatKickoff(kickoff?: string) {
  if (!kickoff) return null;
  const date = new Date(kickoff);
  return Number.isNaN(date.getTime()) ? kickoff : new Intl.DateTimeFormat('en', { dateStyle: 'medium', timeStyle: kickoff.includes('T') ? 'short' : undefined }).format(date);
}

function App() {
  const [fixtures, setFixtures] = useState<Fixture[]>(loadFixtures);
  const [selectedId, setSelectedId] = useState(fixtures[0]?.id ?? '');
  const [simulationInput, setSimulationInput] = useState('5000');
  const simulations = Number(simulationInput);
  const validSimulationCount = Number.isInteger(simulations) && simulations >= 1 && simulations <= 100000;
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<FormValue>(blankForm);
  const [formError, setFormError] = useState('');
  const [notice, setNotice] = useState('');
  const [importError, setImportError] = useState('');
  const [copied, setCopied] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const selected = fixtures.find((fixture) => fixture.id === selectedId) ?? fixtures[0];
  const results = useMemo(() => selected && validSimulationCount ? simulateFixture(selected, simulations) : null, [selected, simulations, validSimulationCount]);
  const rates = selected ? goalRates(selected) : null;
  const kickoff = selected ? formatKickoff(selected.kickoff) : null;

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(fixtures));
    if (selectedId && !fixtures.some((fixture) => fixture.id === selectedId)) setSelectedId(fixtures[0]?.id ?? '');
  }, [fixtures, selectedId]);

  function beginCreate() {
    setEditingId(null);
    setForm(blankForm);
    setFormError('');
    setShowForm(true);
  }

  function beginEdit(fixture: Fixture) {
    setEditingId(fixture.id);
    setForm({
      competition: fixture.competition,
      homeTeam: fixture.homeTeam,
      awayTeam: fixture.awayTeam,
      kickoff: fixture.kickoff ?? '',
      homeExpectedGoals: fixture.homeExpectedGoals == null ? '' : String(fixture.homeExpectedGoals),
      awayExpectedGoals: fixture.awayExpectedGoals == null ? '' : String(fixture.awayExpectedGoals),
    });
    setFormError('');
    setShowForm(true);
  }

  function saveFixture(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const homeRate = form.homeExpectedGoals.trim() ? Number(form.homeExpectedGoals) : undefined;
    const awayRate = form.awayExpectedGoals.trim() ? Number(form.awayExpectedGoals) : undefined;
    if (!form.homeTeam.trim() || !form.awayTeam.trim()) {
      setFormError('Add both a home team and an away team.');
      return;
    }
    if ([homeRate, awayRate].some((rate) => rate !== undefined && (!Number.isFinite(rate) || rate < 0 || rate > 12))) {
      setFormError('Expected goals must be a number from 0 to 12. Leave blank to use the fallback assumption.');
      return;
    }
    const fixture: Fixture = {
      id: editingId ?? `fixture-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      competition: form.competition,
      homeTeam: form.homeTeam.trim(),
      awayTeam: form.awayTeam.trim(),
      ...(form.kickoff.trim() ? { kickoff: form.kickoff.trim() } : {}),
      ...(homeRate !== undefined ? { homeExpectedGoals: homeRate } : {}),
      ...(awayRate !== undefined ? { awayExpectedGoals: awayRate } : {}),
      isSample: false,
    };
    setFixtures((current) => editingId ? current.map((item) => item.id === editingId ? fixture : item) : [...current, fixture]);
    setSelectedId(fixture.id);
    setShowForm(false);
    setFormError('');
    setNotice(editingId ? 'Fixture updated.' : 'Fixture added.');
  }

  function deleteSelected() {
    if (!selected) return;
    if (!window.confirm(`Remove ${selected.homeTeam} vs ${selected.awayTeam}?`)) return;
    const next = fixtures.filter((fixture) => fixture.id !== selected.id);
    setFixtures(next);
    setSelectedId(next[0]?.id ?? '');
    setShowForm(false);
    setNotice('Fixture removed.');
  }

  async function importFile(file?: File) {
    if (!file) return;
    setImportError('');
    try {
      const content = await file.text();
      let parsed: unknown;
      try {
        parsed = JSON.parse(content);
      } catch (error) {
        const detail = error instanceof Error ? error.message : 'The file could not be parsed.';
        throw new Error(`Invalid JSON: ${detail}`);
      }
      const incoming = validateFixtureList(parsed);
      if (fixtures.length && !window.confirm('Importing replaces the current fixture list in this browser. Export your fixtures first if you want to keep them. Continue?')) {
        setNotice('Import canceled. Your current fixtures were kept.');
        return;
      }
      setFixtures(incoming);
      setSelectedId(incoming[0]?.id ?? '');
      setShowForm(false);
      setNotice(`${incoming.length} fixture${incoming.length === 1 ? '' : 's'} imported successfully.`);
    } catch (error) {
      setImportError(error instanceof Error ? error.message : 'Could not import this file.');
    } finally {
      if (fileRef.current) fileRef.current.value = '';
    }
  }

  async function exportFixtures() {
    const json = JSON.stringify(fixtures, null, 2);
    try {
      if (await shareFixtureJson(json)) {
        setNotice('JSON export opened in the Android share sheet.');
        return;
      }
    } catch {
      setNotice('Could not prepare the JSON export on this device.');
      return;
    }

    const blob = new Blob([json], { type: 'application/json' });
    const href = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = href;
    anchor.download = 'g20-fixtures.json';
    anchor.click();
    URL.revokeObjectURL(href);
    setNotice('Fixture data exported as JSON.');
  }

  const xCopy = selected && results && rates
    ? `${selected.homeTeam} v ${selected.awayTeam} | H/D/A ${results.homePercent.toFixed(1)}/${results.drawPercent.toFixed(1)}/${results.awayPercent.toFixed(1)}% | xG (H/A) ${results.homeLambda.toFixed(2)}/${results.awayLambda.toFixed(2)} | Most frequent score ${results.mostLikelyScore} | ${results.simulations.toLocaleString('en')} runs | Inputs H/A: ${rates.homeSource === 'sample' ? 'sample' : rates.homeSource === 'provided' ? 'user-provided, unverified' : 'fallback assumption'} / ${rates.awaySource === 'sample' ? 'sample' : rates.awaySource === 'provided' ? 'user-provided, unverified' : 'fallback assumption'}. Experimental, unvalidated.`
    : '';

  async function copyPost() {
    try {
      await navigator.clipboard.writeText(xCopy);
      setCopied(true);
      setNotice('English X post copied to clipboard.');
      window.setTimeout(() => setCopied(false), 2200);
    } catch {
      setNotice('Clipboard access is unavailable in this browser. Select and copy the post text below.');
    }
  }

  const outcomes = results && selected ? [
    { label: `${selected.homeTeam} win`, value: results.homePercent, count: results.homeWins, color: '#315f4b' },
    { label: 'Draw', value: results.drawPercent, count: results.draws, color: '#e4ad42' },
    { label: `${selected.awayTeam} win`, value: results.awayPercent, count: results.awayWins, color: '#d67b5a' },
  ] : [];

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="page-wrap flex h-[68px] items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="brand-mark" aria-hidden="true">G20</div>
            <div>
              <div className="display text-[15px] font-bold leading-tight">Matchday, made legible.</div>
              <div className="mt-0.5 text-[10px] uppercase tracking-[.17em] text-[#bdc5c3]">Football predictor · experimental</div>
            </div>
          </div>
          <div className="hidden items-center gap-2 rounded-full border border-white/15 px-3 py-1.5 text-[11px] text-[#d7ddd9] sm:flex">
            <span className="h-1.5 w-1.5 rounded-full bg-[#91c4a4]" /> Runs {Capacitor.isNativePlatform() ? 'on this device' : 'in this browser'}
          </div>
          <div className="text-[10px] font-medium tracking-[.1em] text-[#bdc5c3] sm:hidden">{Capacitor.isNativePlatform() ? 'ANDROID APP' : 'BROWSER ONLY'}</div>
        </div>
      </header>

      <main className="page-wrap pb-14 pt-7 sm:pt-10">
        <section className="mb-8 grid gap-5 sm:mb-10 sm:grid-cols-[1fr_auto] sm:items-end">
          <div className="max-w-[700px]">
            <div className="eyebrow mb-3">Your matchday desk / 01</div>
            <h1 className="display text-[34px] font-bold leading-[1.04] sm:text-[48px]">A model you can<br className="hidden sm:block" /> look under the hood of.</h1>
            <p className="mt-3 max-w-[570px] text-[14px] leading-6 text-[#5d6462]">
              Choose a fixture, set the inputs, and run a transparent Poisson simulation. No accounts, feeds, or claims of certainty.
            </p>
          </div>
          <div className="flex items-center gap-2 self-end text-[11px] text-[#686e6b]">
            <span className="h-2 w-2 rounded-full bg-[#55926f]" /> Private by design <span className="text-[#c1bcae]">/</span> data stays here
          </div>
        </section>

        {notice && (
          <div className="status-note mb-5 flex items-center justify-between rounded-xl border border-[#bfd3c3] bg-[#e8f0e8] px-4 py-3 text-[13px] text-[#315f4b]" role="status" data-testid="status-feedback">
            <span className="flex items-center gap-2"><Check size={16} />{notice}</span>
            <button className="btn-quiet !min-h-7 !px-2" aria-label="Dismiss message" onClick={() => setNotice('')} data-testid="button-dismiss-feedback"><X size={15} /></button>
          </div>
        )}

        <div className="grid gap-5 lg:grid-cols-[minmax(0,1.18fr)_minmax(340px,.82fr)] lg:items-start">
          <div className="space-y-5">
            <section className="surface overflow-hidden" aria-labelledby="fixture-heading">
              <div className="flex items-center justify-between border-b border-[#e4dfd3] px-5 py-4 sm:px-6">
                <div>
                  <div className="eyebrow">Fixture desk</div>
                  <h2 className="display mt-1 text-[20px] font-bold" id="fixture-heading">Select a match</h2>
                </div>
                <span className="rounded-full bg-[#e8e5da] px-2.5 py-1 font-mono text-[10px] text-[#59615e]" data-testid="text-fixture-count">{fixtures.length} {fixtures.length === 1 ? 'fixture' : 'fixtures'}</span>
              </div>
              <div className="space-y-4 p-5 sm:p-6">
                {fixtures.some((fixture) => fixture.isSample) && <p className="rounded-lg bg-[#f1eee5] px-3 py-2.5 text-[11px] leading-5 text-[#747970]" data-testid="text-sample-data-note">Preloaded fixtures and any sample goal values are illustrative only—not real match data or statistics.</p>}
                {fixtures.length ? (
                  <>
                    <label className="block">
                      <span className="mb-1.5 block text-[11px] font-bold uppercase tracking-[.09em] text-[#6e7470]">Choose from your fixtures</span>
                      <div className="relative">
                        <select className="field appearance-none pr-10 font-semibold" value={selected?.id ?? ''} onChange={(event) => setSelectedId(event.target.value)} data-testid="select-fixture" aria-label="Select a fixture">
                          {fixtures.map((fixture) => <option value={fixture.id} key={fixture.id}>{fixture.homeTeam} vs {fixture.awayTeam}</option>)}
                        </select>
                        <ChevronDown className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[#737a75]" size={17} />
                      </div>
                    </label>
                    {selected && (
                      <div className="soft-surface p-4 sm:p-5" data-testid={`card-fixture-${selected.id}`}>
                        <div className="flex items-center justify-between gap-3">
                          <span className="eyebrow !text-[10px]" data-testid="text-competition">{selected.competition}</span>
                          {kickoff && <span className="text-[11px] text-[#727772]" data-testid="text-kickoff">{kickoff}</span>}
                        </div>
                        <div className="mt-5 grid grid-cols-[1fr_auto_1fr] items-center gap-2">
                          <div className="display text-[20px] font-bold leading-[1.08] sm:text-[25px]" data-testid="text-home-team">{selected.homeTeam}</div>
                          <div className="font-mono text-[10px] font-medium uppercase tracking-[.16em] text-[#7f827b]">v</div>
                          <div className="display text-right text-[20px] font-bold leading-[1.08] sm:text-[25px]" data-testid="text-away-team">{selected.awayTeam}</div>
                        </div>
                        <div className="mt-5 flex flex-wrap gap-2 border-t border-[#d6d2c6] pt-3">
                          <button className="btn-secondary !min-h-[36px] !px-3 !text-[12px]" onClick={() => beginEdit(selected)} data-testid="button-edit-fixture"><Pencil size={14} /> Edit fixture</button>
                          <button className="btn-danger !min-h-[36px] !px-3 !text-[12px]" onClick={deleteSelected} data-testid="button-delete-fixture"><Trash2 size={14} /> Remove</button>
                        </div>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="rounded-xl border border-dashed border-[#c9c4b7] px-5 py-8 text-center" data-testid="empty-fixtures">
                    <div className="display text-lg font-bold">Your fixture list is clear.</div>
                    <p className="mx-auto mt-1 max-w-xs text-[13px] text-[#6f7571]">Add a match or import your own JSON data to get started.</p>
                  </div>
                )}

                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  <button className="btn-primary mobile-full" onClick={beginCreate} data-testid="button-add-fixture"><FilePlus2 size={16} /> Add a fixture</button>
                  <button className="btn-secondary mobile-full" onClick={exportFixtures} disabled={!fixtures.length} data-testid="button-export-json"><ArrowDownToLine size={16} /> Export JSON</button>
                  <button className="btn-secondary mobile-full sm:col-span-2" onClick={() => fileRef.current?.click()} data-testid="button-import-json"><ArrowUpFromLine size={16} /> Import JSON file</button>
                  <input ref={fileRef} type="file" accept=".json,application/json" className="hidden" onChange={(event) => void importFile(event.target.files?.[0])} data-testid="input-import-file" aria-label="Choose JSON fixture file" />
                </div>
                {importError && <div className="rounded-lg border border-[#e6c2b9] bg-[#fff1ed] p-3 text-[12px] leading-5 text-[#9d443c] whitespace-pre-line" role="alert" data-testid="error-import-json">{importError}</div>}
                <p className="text-[11px] leading-5 text-[#787c75]">Changes are saved in this browser only. Imports replace the current fixture list.</p>

                {showForm && (
                  <form className="rounded-xl border border-[#cfc9bb] bg-[#f6f3ea] p-4 sm:p-5" onSubmit={saveFixture} data-testid="form-fixture">
                    <div className="mb-4 flex items-start justify-between">
                      <div>
                        <div className="eyebrow">Fixture details</div>
                        <h3 className="display mt-1 text-lg font-bold">{editingId ? 'Edit match' : 'Add a match'}</h3>
                      </div>
                      <button type="button" className="btn-quiet !min-h-8 !w-8 !p-0" onClick={() => { setShowForm(false); setFormError(''); }} aria-label="Close fixture form" data-testid="button-close-form"><X size={17} /></button>
                    </div>
                    <div className="space-y-3">
                      <label className="block text-[11px] font-bold text-[#626b66]">Competition
                        <select className="field mt-1.5" value={form.competition} onChange={(event) => setForm({ ...form, competition: event.target.value as Competition })} data-testid="select-competition">
                          {COMPETITIONS.map((competition) => <option key={competition}>{competition}</option>)}
                        </select>
                      </label>
                      <div className="grid gap-3 sm:grid-cols-2">
                        <label className="block text-[11px] font-bold text-[#626b66]">Home team
                          <input className="field mt-1.5" value={form.homeTeam} onChange={(event) => setForm({ ...form, homeTeam: event.target.value })} placeholder="e.g. Northbridge FC" maxLength={80} data-testid="input-home-team" />
                        </label>
                        <label className="block text-[11px] font-bold text-[#626b66]">Away team
                          <input className="field mt-1.5" value={form.awayTeam} onChange={(event) => setForm({ ...form, awayTeam: event.target.value })} placeholder="e.g. Riverside Athletic" maxLength={80} data-testid="input-away-team" />
                        </label>
                      </div>
                      <label className="block text-[11px] font-bold text-[#626b66]">Kickoff <span className="font-normal text-[#8a8b84]">optional</span>
                        <input className="field mt-1.5" value={form.kickoff} onChange={(event) => setForm({ ...form, kickoff: event.target.value })} placeholder="e.g. 2025-08-16 15:00" maxLength={80} data-testid="input-kickoff" />
                      </label>
                      <div className="grid gap-3 sm:grid-cols-2">
                        <label className="block text-[11px] font-bold text-[#626b66]">Home expected goals λ
                          <input className="field mt-1.5 font-mono" inputMode="decimal" type="number" min="0" max="12" step="0.01" value={form.homeExpectedGoals} onChange={(event) => setForm({ ...form, homeExpectedGoals: event.target.value })} placeholder="Fallback: 1.45" data-testid="input-home-xg" />
                          <span className="mt-1 block font-normal text-[#858980]">Leave blank to use fallback.</span>
                        </label>
                        <label className="block text-[11px] font-bold text-[#626b66]">Away expected goals λ
                          <input className="field mt-1.5 font-mono" inputMode="decimal" type="number" min="0" max="12" step="0.01" value={form.awayExpectedGoals} onChange={(event) => setForm({ ...form, awayExpectedGoals: event.target.value })} placeholder="Fallback: 1.15" data-testid="input-away-xg" />
                          <span className="mt-1 block font-normal text-[#858980]">Leave blank to use fallback.</span>
                        </label>
                      </div>
                      <div className="rounded-lg bg-[#e8e5da] px-3 py-2.5 text-[11px] leading-5 text-[#606a63]">
                        Entered values are inputs only and not independently verified. Blank rates use the stated fallback assumptions.
                      </div>
                      {formError && <p className="text-[12px] text-[#a9443c]" role="alert" data-testid="error-fixture-form">{formError}</p>}
                      <button className="btn-primary w-full" type="submit" data-testid="button-save-fixture">{editingId ? 'Save changes' : 'Add fixture'}</button>
                    </div>
                  </form>
                )}
              </div>
            </section>

            <section className="surface p-5 sm:p-6" aria-labelledby="model-heading">
              <div className="flex items-start gap-3">
                <div className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-full bg-[#e4e9df] text-[#416c52]"><Info size={16} /></div>
                <div>
                  <div className="eyebrow">Model notes</div>
                  <h2 className="display mt-1 text-[18px] font-bold" id="model-heading">Simple by design. Clear about its limits.</h2>
                  <p className="mt-2 text-[13px] leading-6 text-[#646c67]">Each team's goals are drawn independently from a Poisson distribution using its expected-goals λ. Win, draw, loss, and the most frequent scoreline come only from those simulated runs.</p>
                  <p className="mt-2 text-[12px] leading-5 text-[#777c76]">This experimental illustration is not validated and makes no claim of accuracy. User-entered goal values are not independently verified; missing values use explicit fallback assumptions.</p>
                </div>
              </div>
            </section>
          </div>

          <aside className="space-y-5">
            <section className="surface overflow-hidden" aria-labelledby="simulation-heading">
              <div className="flex items-center justify-between border-b border-[#e4dfd3] px-5 py-4 sm:px-6">
                <div>
                  <div className="eyebrow">Simulation / 02</div>
                  <h2 className="display mt-1 text-[20px] font-bold" id="simulation-heading">Possible outcomes</h2>
                </div>
                <div className="rounded-full border border-[#d8d2c5] px-2.5 py-1 font-mono text-[10px] text-[#69716a]" data-testid="status-model">POISSON</div>
              </div>
              <div className="p-5 sm:p-6">
                <label className="mb-5 flex items-center justify-between gap-3">
                  <span className="text-[12px] font-semibold text-[#525e57]">Simulated matches</span>
                  <span className="flex items-center gap-2">
                    <input className="field !min-h-[38px] !w-[112px] !px-2.5 text-right font-mono font-medium" type="number" min="1" max="100000" step="1" value={simulationInput} onChange={(event) => setSimulationInput(event.target.value)} onBlur={() => {
                      if (!validSimulationCount) setSimulationInput('5000');
                    }} data-testid="input-simulation-count" />
                    <span className="text-[11px] text-[#777c76]">runs</span>
                  </span>
                </label>

                {selected && results ? (
                  <>
                    <div className="mb-5 flex items-center justify-between gap-2 rounded-xl bg-[#222e38] px-4 py-3.5 text-[#f7f2e7]">
                      <div className="min-w-0">
                        <div className="truncate text-[12px] font-semibold" data-testid="text-result-match">{selected.homeTeam} <span className="font-normal text-[#b7c2bd]">vs</span> {selected.awayTeam}</div>
                        <div className="mt-1 text-[10px] text-[#bac4bd]">{selected.competition}</div>
                      </div>
                      <div className="display shrink-0 text-[10px] font-bold uppercase tracking-[.12em] text-[#efb290]">{results.simulations.toLocaleString('en')} runs</div>
                    </div>

                    <div className="space-y-4" data-testid="output-outcome-probabilities">
                      {outcomes.map((outcome, index) => (
                        <div key={outcome.label} data-testid={`outcome-${index}`}>
                          <div className="mb-1.5 flex items-baseline justify-between gap-2">
                            <span className="truncate text-[12px] font-semibold text-[#414c47]">{outcome.label}</span>
                            <span className="font-mono text-[19px] font-medium tracking-tight" data-testid={`text-outcome-percent-${index}`}>{outcome.value.toFixed(1)}<span className="ml-0.5 text-[12px]">%</span></span>
                          </div>
                          <div className="result-bar"><span style={{ width: `${outcome.value}%`, backgroundColor: outcome.color }} /></div>
                          <div className="mt-1 text-right font-mono text-[10px] text-[#858980]">{outcome.count.toLocaleString('en')} runs</div>
                        </div>
                      ))}
                    </div>

                    <div className="my-5 border-t border-[#e5e0d5]" />
                    <div className="grid grid-cols-2 gap-3">
                      <div className="soft-surface p-3.5" data-testid="output-expected-goals">
                        <div className="eyebrow !text-[9px]">Expected goals · λ</div>
                        <div className="mt-2 font-mono text-[16px] font-medium" data-testid="text-expected-goals">{results.homeLambda.toFixed(2)} <span className="text-[#95968e]">—</span> {results.awayLambda.toFixed(2)}</div>
                        <div className="mt-1 truncate text-[10px] text-[#6d746e]">{selected.homeTeam} / {selected.awayTeam}</div>
                      </div>
                      <div className="soft-surface p-3.5" data-testid="output-most-likely-score">
                        <div className="eyebrow !text-[9px]">Most frequent score</div>
                        <div className="display mt-1 text-[25px] font-bold" data-testid="text-most-likely-score">{results.mostLikelyScore}</div>
                        <div className="mt-0.5 font-mono text-[10px] text-[#6d746e]">{results.scoreFrequency.toLocaleString('en')} of {results.simulations.toLocaleString('en')}</div>
                      </div>
                    </div>

                    <div className="mt-3 rounded-lg border border-[#e4dfd3] bg-[#f8f5ed] px-3.5 py-3" data-testid="output-goal-rate-sources">
                      <div className="mb-2 text-[10px] font-bold uppercase tracking-[.09em] text-[#656e68]">Expected-goal input source</div>
                      <div className="grid grid-cols-2 gap-2 text-[10px] leading-4">
                        <div><div className="font-semibold text-[#48534c]">{selected.homeTeam}</div><span className={rates?.homeSource === 'fallback' ? 'text-[#57755e]' : 'text-[#8d5544]'} data-testid="text-home-rate-source">{rates?.homeSource === 'sample' ? 'Sample value · illustrative only' : rates?.homeSource === 'provided' ? 'User-provided · not independently verified' : 'Fallback assumption · 1.45'}</span></div>
                        <div><div className="font-semibold text-[#48534c]">{selected.awayTeam}</div><span className={rates?.awaySource === 'fallback' ? 'text-[#57755e]' : 'text-[#8d5544]'} data-testid="text-away-rate-source">{rates?.awaySource === 'sample' ? 'Sample value · illustrative only' : rates?.awaySource === 'provided' ? 'User-provided · not independently verified' : 'Fallback assumption · 1.15'}</span></div>
                      </div>
                    </div>
                    <p className="mt-4 text-[11px] leading-[1.55] text-[#7a7c74]" data-testid="text-rounding-note">Win, draw, and loss percentages are rounded to one decimal place and adjusted to total exactly 100.0%.</p>
                  </>
                ) : (
                  <div className="rounded-xl border border-dashed border-[#c9c4b7] p-7 text-center" data-testid="empty-results">
                    {selected && !validSimulationCount ? <RotateCcw size={20} className="mx-auto text-[#88918a]" /> : <RotateCcw size={20} className="mx-auto text-[#88918a]" />}
                    <div className="display mt-2 font-bold">{selected ? 'Choose a valid run count.' : 'Add a fixture to simulate.'}</div>
                    <p className="mt-1 text-[12px] text-[#737872]">{selected ? 'Enter a whole number from 1 to 100,000.' : 'The model will show outcomes here.'}</p>
                  </div>
                )}
              </div>
            </section>

            <section className="surface p-5 sm:p-6" aria-labelledby="post-heading">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="eyebrow">Share-ready / 03</div>
                  <h2 className="display mt-1 text-[20px] font-bold" id="post-heading">English X post</h2>
                </div>
                <span className="rounded-md border border-[#d9d4c8] px-2 py-1 font-mono text-[10px] text-[#747a73]">PREVIEW</span>
              </div>
              <p className="mt-2 text-[12px] leading-5 text-[#70766f]">Includes the inputs, simulation and the caveat. Review before sharing.</p>
              {xCopy ? (
                <>
                  <p className={`mt-3 text-right font-mono text-[10px] ${xCopy.length > 280 ? 'text-[#a9443c]' : 'text-[#70766f]'}`} data-testid="text-x-character-count">
                    {xCopy.length > 280 ? `${xCopy.length}/280 characters · shorten before posting` : `${xCopy.length}/280 characters`}
                  </p>
                  <textarea readOnly value={xCopy} className="mt-4 min-h-[190px] w-full resize-y rounded-xl border border-[#d8d2c5] bg-[#f5f2e9] p-3.5 font-mono text-[11px] leading-[1.7] text-[#424d47] outline-none focus:border-[#477b62]" aria-label="English X post copy" data-testid="textarea-x-copy" />
                  <button className="btn-primary mt-3 w-full" onClick={() => void copyPost()} data-testid="button-copy-post"><Clipboard size={16} />{copied ? 'Copied' : 'Copy post text'}</button>
                </>
              ) : (
                <p className="mt-4 rounded-lg bg-[#f1eee5] p-4 text-[12px] text-[#777c76]" data-testid="empty-post">A share preview appears when a fixture is selected.</p>
              )}
            </section>
          </aside>
        </div>
        <footer className="mt-9 flex flex-col gap-2 border-t border-[#d9d4c8] pt-4 text-[10px] leading-5 text-[#777c76] sm:flex-row sm:items-center sm:justify-between">
          <span>G20 Football Predictor <span className="mx-1 text-[#b1ad9f]">/</span> A local, illustrative matchday tool.</span>
          <span>No server · No accounts · No external data</span>
        </footer>
      </main>
    </div>
  );
}

export default App;
