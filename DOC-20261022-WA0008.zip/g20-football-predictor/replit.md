# G20 Football Predictor

A phone-friendly, browser-only football match predictor with editable JSON fixtures and transparent, experimental Poisson simulations.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- Replit Run opens the `G20 Football Predictor` web preview.
- `pnpm --filter @workspace/g20-football-predictor run test` — test the local simulation math
- `pnpm --filter @workspace/g20-football-predictor run typecheck` — typecheck the app
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- The predictor does not require the API server, database, credentials, or external data.

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/g20-football-predictor/src/App.tsx` — fixture management, JSON import/export, and prediction UI
- `artifacts/g20-football-predictor/src/simulation.mjs` — Poisson Monte Carlo model
- `artifacts/g20-football-predictor/src/simulation.test.mjs` — deterministic simulation tests
- `artifacts/g20-football-predictor/README.md` — fixture JSON shape and run/test instructions

## Architecture decisions

- Match inputs and simulations stay in the browser; fixtures persist in local storage.
- Missing expected-goal inputs use explicit fallback lambdas (home 1.45, away 1.15); sample inputs, user-provided inputs, and fallbacks must remain clearly distinct.
- Simulation outcomes are illustrative and unvalidated; never present them as accurate forecasts.

## Product

Users can manage fixtures for eight European competitions, import/export JSON, configure simulation counts, inspect Poisson-based outcome rates and expected goals, and copy an English X post.

## User preferences

- No paid data APIs, subscriptions, database, server, or API keys for the current predictor.
- Live football data integration is deferred to a later phase.

## Gotchas

- Imports replace the local fixture list; export first if the current list should be kept.
- Preloaded team names and rates are sample values, not real football statistics.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
